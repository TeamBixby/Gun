<a align="center" href="https://raw.githubusercontent.com/TeamBixby/Gun/master/assets/icon.png">      </a>
<h1 align="center"><br>Gun :: awesome gun plugin</h1>
<p align="center">
<!-- [![Discord](https://img.shields.io/discord/773833936942006283.svg?logo=discord)](https://discord.gg/Py2vSwg3B3) -->
<a href="https://discord.gg/Py2vSwg3B3"><img src="https://img.shields.io/discord/773833936942006283.svg?logo=discord)"></a><a href="https://poggit.pmmp.io/ci/TeamBixby/Gun/Gun"><img src="https://poggit.pmmp.io/ci.shield/TeamBixby/Gun/Gun?style=flat-square"></a>
</p>

## :clipboard: Features

* Scope support
* Ammo support
* Easy gun management
* popup-info support
* Customizable-config

## :pushpin: Commands

##### Command
|command|description|permission|
|---|---|---|
|/gun|Opens gun ui|gun.command|